-- Databricks notebook source
-- MAGIC %md
-- MAGIC query data via unity catalog using 3 namespace

-- COMMAND ----------

select * from demo_catalog.demo_schema.circuits

-- COMMAND ----------

use catalog demo_catalog;
use schema demo_schema;
select * from circuits

-- COMMAND ----------

select current_catalog()

-- COMMAND ----------

show catalogs

-- COMMAND ----------

use catalog demo_catalog

-- COMMAND ----------

select current_schema()

-- COMMAND ----------

show schemas in demo_catalog

-- COMMAND ----------

use schema demo_schema

-- COMMAND ----------

select current_schema()

-- COMMAND ----------

show tables

-- COMMAND ----------

-- MAGIC %python
-- MAGIC df=spark.sql("select * from demo_catalog.demo_schema.circuits")
-- MAGIC display(df)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC df=spark.table("demo_catalog.demo_schema.circuits")
-- MAGIC display(df)