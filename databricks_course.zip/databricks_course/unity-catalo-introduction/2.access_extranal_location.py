# Databricks notebook source
dbutils.fs.ls('abfss://demo@formula1dlgrucext.dfs.core.windows.net/')

# COMMAND ----------

display(spark.read.csv('abfss://demo@formula1dlgrucext.dfs.core.windows.net/circuits.csv'))