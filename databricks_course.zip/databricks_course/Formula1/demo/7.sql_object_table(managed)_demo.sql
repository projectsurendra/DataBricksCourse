-- Databricks notebook source
-- MAGIC %md
-- MAGIC Learning objects
-- MAGIC 1.create managed table in python
-- MAGIC 2.create managed table in sql
-- MAGIC 3.effect of dropping the managed tables
-- MAGIC 4.describe table

-- COMMAND ----------

/* in managed tables metadata,data taken care by spark */

-- COMMAND ----------

-- MAGIC %run "../includes/configaration"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df=spark.read.parquet(f"{presentation_folder_path}/race_results")
-- MAGIC display(race_results_df)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #create table by using python
-- MAGIC race_results_df.write.format("parquet").saveAsTable("demo.race_results_mng_python_table")

-- COMMAND ----------

show tables in demo

-- COMMAND ----------

describe table extended demo.race_results_mng_python_table

-- COMMAND ----------

select * 
from demo.race_results_mng_python_table
where race_year=2020

-- COMMAND ----------

/*create table by using sql*/

create table if not exists demo.race_results_mng_sql_table
as
select *
from demo.race_results_mng_python_table
where race_year=2020


-- COMMAND ----------

show tables in demo


-- COMMAND ----------

describe table extended demo.race_results_mng_sql_table

-- COMMAND ----------

drop table demo.race_results_mng_sql_table

-- COMMAND ----------

show tables in demo