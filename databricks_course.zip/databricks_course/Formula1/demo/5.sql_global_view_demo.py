# Databricks notebook source
# MAGIC %md
# MAGIC Global Temporary views
# MAGIC 1.create global temporary views on the notebook
# MAGIC 2.access the view from the sql cell
# MAGIC 3.acces the view from python cell
# MAGIC 4.access the viem from the other notebook

# COMMAND ----------

# MAGIC %run "../includes/configaration"

# COMMAND ----------

races_results_df=spark.read.parquet(f"{presentation_folder_path}/race_results")
display(races_results_df)

# COMMAND ----------

races_results_df.createOrReplaceGlobalTempView("gv_races_results_df")

# COMMAND ----------

# MAGIC %sql
# MAGIC show tables in global_temp

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from global_temp.gv_races_results_df
# MAGIC where race_year=2020

# COMMAND ----------

df=spark.sql("select * from global_temp.gv_races_results_df")
display(df)