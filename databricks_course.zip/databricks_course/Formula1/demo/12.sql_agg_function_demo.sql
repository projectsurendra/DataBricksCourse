-- Databricks notebook source
select count(*)
from f1_processed.drivers

-- COMMAND ----------

select count(*),max(dob),min(dob)
from f1_processed.drivers

-- COMMAND ----------

select *
from f1_processed.drivers
where dob = (select max(dob) from f1_processed.drivers)


-- COMMAND ----------

select count(*)
from f1_processed.drivers
where nationality='British'

-- COMMAND ----------

select * from f1_processed.drivers

-- COMMAND ----------

select nationality,count(*)
from f1_processed.drivers
where driver_id <=100
group by nationality

-- COMMAND ----------

select nationality,count(*)
from f1_processed.drivers
group by nationality
having count(*)>=100
