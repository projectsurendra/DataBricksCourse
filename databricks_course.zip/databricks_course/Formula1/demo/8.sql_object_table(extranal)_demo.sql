-- Databricks notebook source
-- MAGIC %md
-- MAGIC Learnings objectives
-- MAGIC 1.create the table using python
-- MAGIC 2.create the table using sql
-- MAGIC 3.effect of dropping the an external table

-- COMMAND ----------

/*in extranal tables metadata taken care by spark,data taken care by user*/

-- COMMAND ----------

-- MAGIC %run "../includes/configaration"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df=spark.read.parquet(f"{presentation_folder_path}/race_results")
-- MAGIC display(race_results_df)
-- MAGIC race_results_df.printSchema()

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").option("path",f"{presentation_folder_path}/race_results_ext_py").saveAsTable("demo.race_results_ext_py_table")

-- COMMAND ----------

describe table extended demo.race_results_ext_py_table

-- COMMAND ----------

create table  demo.race_results_ext_sql_t
(
  race_year int,
  race_name string,
  race_date timestamp,
  circuit_id int,
  driver_name string,
  driver_number int,
  driver_nationality string,
  team string,
  grid int,
  fastest_lap string,
  race_time string,
  points float,
  position string,
  circuit_location string,
  created_date timestamp
)
using parquet
location "/mnt/formula1dlravi/presentation/race_results_ext_sql_t"

-- COMMAND ----------

show tables in demo

-- COMMAND ----------

insert into demo.race_results_ext_sql_t
select * from demo.race_results_ext_py_table where race_year=2020

-- COMMAND ----------

select count(*)  from demo.race_results_ext_sql_t

-- COMMAND ----------

drop table demo.race_results_ext_sql_t

-- COMMAND ----------

show tables in demo

-- COMMAND ----------

select * from demo.race_results_ext_sql_t