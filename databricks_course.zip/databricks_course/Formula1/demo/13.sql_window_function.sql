-- Databricks notebook source
select *,row_number() over (order by natinality par) as now_number

-- COMMAND ----------

select name,nationality,dob, rank() over (partition by nationality order by dob desc) as rank
from f1_processed.drivers

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ######we can use more functions like dense_rank,Row_number......etc