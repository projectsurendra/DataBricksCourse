# Databricks notebook source
# MAGIC %run "../includes/configaration"

# COMMAND ----------

race_results_df=spark.read.parquet(f"{presentation_folder_path}/race_results")
display(race_results_df)

# COMMAND ----------

demo_df=race_results_df.filter(race_results_df.race_year==2020)
display(demo_df)

# COMMAND ----------

from pyspark.sql.functions import count,countDistinct,sum

# COMMAND ----------

#df1=demo_df.select(count(demo_df.race_name).alias("count_rows"))
#df1=demo_df.select(countDistinct(demo_df.race_name).alias("count_rows"))
#df1=demo_df.select(sum(demo_df.points).alias("count_sum"))
#display(df1)
#display(demo_df.filter(demo_df.driver_name=='Lewis Hamilton').select(sum(demo_df.points).alias("count_sum")))
display(demo_df.filter(demo_df.driver_name =='Lewis Hamilton').select(sum(demo_df.points).alias("total_points"),countDistinct(demo_df.race_name).alias("number_of_races")))

# COMMAND ----------

df2=demo_df.groupBy(demo_df.driver_name).sum("points")
df2.show()

# COMMAND ----------

display(demo_df.groupBy(demo_df.driver_name).agg(sum(demo_df.points).alias("total_points"),countDistinct(demo_df.race_name).alias("number_of_races")))

# COMMAND ----------

demo_grouped_df=demo_df.groupBy(demo_df.race_year,demo_df.driver_name).agg(sum(demo_df.points).alias("total_points"),countDistinct(demo_df.race_name).alias("number_of_races"))
display(demo_grouped_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Window Functions

# COMMAND ----------

demo_df=race_results_df.filter("race_year in (2019,2020)")
display(demo_df)

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import rank,dense_rank,row_number,desc


# COMMAND ----------

#window_function=Window.partitionBy(demo_df1.race_year).orderBy(demo_df1.number_of_races.desc())
driverRankSpec=Window.partitionBy("race_year").orderBy(desc("total_points"))

# COMMAND ----------

display(demo_grouped_df.withColumn("rank",rank().over(driverRankSpec)).withColumn("dense_rank",dense_rank().over(driverRankSpec)).withColumn("row_number",row_number().over(driverRankSpec)))