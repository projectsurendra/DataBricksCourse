# Databricks notebook source
# MAGIC %run "../includes/configaration"

# COMMAND ----------

dbutils.fs.mounts()

# COMMAND ----------

display(dbutils.fs.ls(processed_folder_path))

# COMMAND ----------

races_df=spark.read.parquet(f"{processed_folder_path}/races")
display(races_df)

# COMMAND ----------

#SQL
#races_filtered_df=races_df.filter("race_year = 2019 and round <=5")
races_filtered_df=races_df.where("race_year = 2019 and round <=5")
display(races_filtered_df)


# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

#python
#races_filtered_df1=races_df.filter(races_df.race_year == 2019)
#races_filtered_df1=races_df.filter(col("race_year") == 2019)
#races_filtered_df1=races_df.filter((races_df["race_year"] == 2019) & (races_df["round"] <=5))
races_filtered_df1=races_df.where((races_df["race_year"] == 2019) & (races_df["round"] <=5))
display(races_filtered_df1)