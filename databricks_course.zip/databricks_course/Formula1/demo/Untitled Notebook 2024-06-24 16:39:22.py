# Databricks notebook source
df=spark.sql("select *from f1_demo.results_managed")

# COMMAND ----------

display(df)