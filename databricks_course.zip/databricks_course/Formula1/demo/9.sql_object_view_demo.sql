-- Databricks notebook source
-- MAGIC %md
-- MAGIC VIEWS ON TABLES
-- MAGIC 1.create temp view
-- MAGIC 2.create global temp view
-- MAGIC 3.create permanent view

-- COMMAND ----------

create temp view v_race_results
as
select *
from demo.race_results_python_table
where race_year=2020

-- COMMAND ----------

create or replace temp view v_race_results
as
select *
from demo.race_results_python_table
where race_year=2020

-- COMMAND ----------

select * from v_race_results

-- COMMAND ----------

/*global view are registar in global_temp database*/
create or replace global temp view gv_race_results
as
select *
from demo.race_results_python_table
where race_year=2012

-- COMMAND ----------

show tables in global_temp

-- COMMAND ----------

select * from global_temp.gv_race_results

-- COMMAND ----------

/* permanent view are registar in hive_meta store */
create or replace view demo.pv_race_results
as
select *
from demo.race_results_python_table
where race_year=2000

-- COMMAND ----------

show tables in default

-- COMMAND ----------

select * from demo.pv_race_results

-- COMMAND ----------

drop view default.pv_race_results