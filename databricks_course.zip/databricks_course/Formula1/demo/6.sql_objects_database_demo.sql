-- Databricks notebook source
-- MAGIC %md
-- MAGIC Lesson Objectives
-- MAGIC 1.Spark SQL Documentation
-- MAGIC 2.create database demo
-- MAGIC 3.Data tab in the UI
-- MAGIC 4.Show command
-- MAGIC 5.Describe command
-- MAGIC 6.find the current database

-- COMMAND ----------

create database demo

-- COMMAND ----------

create database if not exists demo

-- COMMAND ----------

show databases

-- COMMAND ----------

describe database demo

-- COMMAND ----------

describe database extended demo

-- COMMAND ----------

select current_database()

-- COMMAND ----------

use demo

-- COMMAND ----------

show tables in default

-- COMMAND ----------

select current_database()

-- COMMAND ----------

show tables in default