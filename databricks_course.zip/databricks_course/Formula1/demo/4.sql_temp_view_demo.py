# Databricks notebook source
# MAGIC %md
# MAGIC Access adatframes using SQL
# MAGIC 1.create the temporary view on dataframes
# MAGIC 2.access the view from SQL cell
# MAGIC 3.access the viev from Python Cell

# COMMAND ----------

# MAGIC %run "../includes/configaration"

# COMMAND ----------

race_results_df=spark.read.parquet(f"{presentation_folder_path}/race_results")
#display(race_results_df)

# COMMAND ----------

race_results_df.createOrReplaceTempView("v_race_results")

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*)
# MAGIC from v_race_results
# MAGIC where race_year=2020

# COMMAND ----------

race_results_2019_df=spark.sql("select * from v_race_results where race_year=2019")
display(race_results_2019_df)