-- Databricks notebook source
select * from v_race_results

-- COMMAND ----------

select * from global_temp.gv_race_results

-- COMMAND ----------

show tables in f1_demo

-- COMMAND ----------

desc table extended f1_demo.driver_merge

-- COMMAND ----------

desc table extended f1_demo.results_managed

-- COMMAND ----------

desc table extended f1_demo.results_external

-- COMMAND ----------

