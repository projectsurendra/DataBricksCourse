# Databricks notebook source
# MAGIC %run "../includes/configaration"

# COMMAND ----------

circutes_df=spark.read.parquet(f"{processed_folder_path}/circutes")\
    .filter("circuit_id <70")\
    .withColumnRenamed("name","circuit_name")
display(circutes_df)

# COMMAND ----------

races_df=spark.read.parquet(f"{processed_folder_path}/races").filter("race_year==2019").withColumnRenamed("name","race_name")
display(races_df)

# COMMAND ----------

# MAGIC %md
# MAGIC INNER_JOIN
# MAGIC
# MAGIC

# COMMAND ----------

race_circutes_df=circutes_df.join(races_df,circutes_df.circuit_id == races_df.circuit_id,"inner")\
    .select(circutes_df.circuit_name,circutes_df.location,circutes_df.country,races_df.race_name,races_df.round)
display(race_circutes_df)

# COMMAND ----------

display(race_circutes_df.select("circuit_name"))

# COMMAND ----------

# MAGIC %md
# MAGIC OUTER_JOIN

# COMMAND ----------

#Left outer join
race_circutes_df=circutes_df.join(races_df,circutes_df.circuit_id == races_df.circuit_id,"left")
display(race_circutes_df)

# COMMAND ----------

race_circutes_df=circutes_df.join(races_df,circutes_df.circuit_id == races_df.circuit_id,"right")
display(race_circutes_df)

# COMMAND ----------

race_circutes_df=circutes_df.join(races_df,circutes_df.circuit_id == races_df.circuit_id,"outer")
display(race_circutes_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Left_semi_join

# COMMAND ----------

race_circutes_df=circutes_df.join(races_df,circutes_df.circuit_id == races_df.circuit_id,"semi")
display(race_circutes_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Left_anti_join

# COMMAND ----------

race_circutes_df=circutes_df.join(races_df,circutes_df.circuit_id == races_df.circuit_id,"anti")
display(race_circutes_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Cross_join

# COMMAND ----------

race_circutes_df=circutes_df.crossJoin(races_df)
display(race_circutes_df)