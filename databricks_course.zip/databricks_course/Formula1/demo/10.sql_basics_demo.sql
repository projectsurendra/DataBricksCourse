-- Databricks notebook source
show databases

-- COMMAND ----------

show tables in f1_raw

-- COMMAND ----------

describe database extended f1_raw

-- COMMAND ----------

describe database extended f1_processed

-- COMMAND ----------

show tables in f1_processed

-- COMMAND ----------

select * from f1_processed.drivers

-- COMMAND ----------

desc table f1_processed.drivers

-- COMMAND ----------

select name,dob as data_of_birth,nationality
from f1_processed.drivers
where (nationality='British' and dob >='1990-01-01') or nationality='Indian'
order by 2 desc

-- COMMAND ----------

