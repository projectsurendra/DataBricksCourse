-- Databricks notebook source
use f1_processed

-- COMMAND ----------

/*select *,concat_ws('-',driver_ref,code) as new_driver_ref
from f1_processed.drivers
or */
select *,concat(driver_ref,'-',code) as new_driver_ref
from f1_processed.drivers

-- COMMAND ----------

select *,split(name,' ' )[0] as forename,split(name,' ' )[1] as surname
from f1_processed.drivers

-- COMMAND ----------

select *,current_timestamp()
from f1_processed.drivers

-- COMMAND ----------

select *, date_format(dob, 'dd-MM-yyyy')
from f1_processed.drivers

-- COMMAND ----------

select dob, date_add(dob,10 )
from f1_processed.drivers

-- COMMAND ----------

select dob, add_months(dob,1 )
from f1_processed.drivers

-- COMMAND ----------

select dob, add_months(dob,12 )
from f1_processed.drivers