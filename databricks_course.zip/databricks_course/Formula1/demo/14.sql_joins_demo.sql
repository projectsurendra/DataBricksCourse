-- Databricks notebook source
select * from f1_presentation.driver_standings

-- COMMAND ----------

create or replace temp view v_driver_standing_2018
as
select *
from f1_presentation.driver_standings
where race_year=2018

-- COMMAND ----------

select * from v_driver_standing_2018

-- COMMAND ----------

create or replace temp view v_driver_standing_2020
as
select *
from f1_presentation.driver_standings
where race_year=2020

-- COMMAND ----------

select * from v_driver_standing_2020

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###########INNER JOIN

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###INNER JOIN

-- COMMAND ----------

select *
from v_driver_standing_2018 as d_2018
join v_driver_standing_2020 as d_2020
on d_2018.driver_name=d_2020.driver_name

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###LEFT JOIN

-- COMMAND ----------

select *
from v_driver_standing_2018 as d_2018
left join v_driver_standing_2020 as d_2020
on d_2018.driver_name=d_2020.driver_name

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###RIGHT JOIN

-- COMMAND ----------

select *
from v_driver_standing_2018 as d_2018
right join v_driver_standing_2020 as d_2020
on d_2018.driver_name=d_2020.driver_name

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###OUTER JOIN

-- COMMAND ----------

select *
from v_driver_standing_2018 as d_2018
full outer join v_driver_standing_2020 as d_2020
on d_2018.driver_name=d_2020.driver_name

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###SEMI JOIN

-- COMMAND ----------

select *
from v_driver_standing_2018 as d_2018
semi join v_driver_standing_2020 as d_2020
on d_2018.driver_name=d_2020.driver_name

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###ANTI JOIN

-- COMMAND ----------

select *
from v_driver_standing_2018 as d_2018
anti join v_driver_standing_2020 as d_2020
on d_2018.driver_name=d_2020.driver_name

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###CROSS JOIN

-- COMMAND ----------

select *
from v_driver_standing_2018 as d_2018
cross join v_driver_standing_2020 as d_2020