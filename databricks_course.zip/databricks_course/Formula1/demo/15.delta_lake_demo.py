# Databricks notebook source
# MAGIC %md
# MAGIC ######1.write data to delta lake(managed table)
# MAGIC ######2.write data to delta lake(extranal table)
# MAGIC ######3.Read data from delta lake(table)
# MAGIC ######4.Read fata from delta lake(file)
# MAGIC

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlgr/raw"))

# COMMAND ----------

# MAGIC %sql
# MAGIC create database if not exists f1_demo
# MAGIC location '/mnt/formula1dlgr/demo'

# COMMAND ----------

results_df=spark.read.option("inferschema",True).json("dbfs:/mnt/formula1dlgr/raw/2021-03-28/results.json")
display(results_df)

# COMMAND ----------

results_df.write.format("delta").mode("overwrite").saveAsTable("f1_demo.results_managed")


# COMMAND ----------

display(spark.read.format('delta').load('/mnt/formula1dlgr/demo/results_managed'))
#display(spark.read.delta('/mnt/formula1dlgr/demo/results_managed'))---It won't work(DataFrameReader' object has no attribute 'delta')

# COMMAND ----------

# MAGIC %sql
# MAGIC desc table extended f1_demo.results_managed

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_demo.results_managed

# COMMAND ----------

results_df.write.format("delta").mode("overwrite").save("/mnt/formula1dlgr/demo/results_external")
#results_df.write.format("delta").mode("overwrite").save("/mnt/formula1dlgr/demo/results_external_Ravi")


# COMMAND ----------

display(spark.read.format("delta").load("/mnt/formula1dlgr/demo/results_external"))

# COMMAND ----------

# MAGIC %sql
# MAGIC create table f1_demo.results_external
# MAGIC using delta
# MAGIC location "/mnt/formula1dlgr/demo/results_external"

# COMMAND ----------

# MAGIC %sql
# MAGIC describe table extended f1_demo.results_external

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from f1_demo.results_external

# COMMAND ----------

results_df.write.format("delta").mode("overwrite").partitionBy("constructorId").saveAsTable("f1_demo.results_managed_parttion")

# COMMAND ----------

# MAGIC %sql
# MAGIC show partitions f1_demo.results_managed_parttion

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_demo.results_managed_parttion

# COMMAND ----------

# MAGIC %md
# MAGIC #####1.update delta table
# MAGIC #####2.delete from delta table

# COMMAND ----------

# MAGIC %sql
# MAGIC update f1_demo.results_managed
# MAGIC set points=11-position
# MAGIC where position<=10

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_demo.results_managed

# COMMAND ----------

from delta.tables import *
from pyspark.sql.functions import *

deltaTable = DeltaTable.forPath(spark, '/mnt/formula1dlgr/demo/results_managed')

# Declare the predicate by using a SQL-formatted string.
deltaTable.update(
  condition = "position<=10",
  set = { "points": "21-position" }
)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_demo.results_managed

# COMMAND ----------

# MAGIC %sql
# MAGIC delete from f1_demo.results_managed
# MAGIC where position >10

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from f1_demo.results_managed

# COMMAND ----------

from delta.tables import *
from pyspark.sql.functions import *

deltaTable = DeltaTable.forPath(spark, '/mnt/formula1dlgr/demo/results_managed')
deltaTable.delete("points=0")

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from f1_demo.results_managed

# COMMAND ----------

# MAGIC  %sql
# MAGIC  update delta.`/mnt/formula1dlgr/demo/results_managed`
# MAGIC  set points=10+10
# MAGIC  where position=1
# MAGIC
# MAGIC  
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #####Upsert using merge

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlgr/raw"))

# COMMAND ----------

driver_day1_df=spark.read\
.option("inferschema",True)\
.json("dbfs:/mnt/formula1dlgr/raw/2021-03-21/drivers.json")\
.filter("driverId<=10")\
.select("driverId","dob","name.forename","name.surname")

# COMMAND ----------

driver_day1_df.createOrReplaceTempView("drivers_day1")

# COMMAND ----------

from pyspark.sql.functions import upper

driver_day2_df=spark.read\
.option("inferschema",True)\
.json("dbfs:/mnt/formula1dlgr/raw/2021-03-28/drivers.json")\
.filter("driverId BETWEEN 6 AND 15")\
.select("driverId","dob",upper("name.forename").alias("forename"),upper("name.surname").alias("surname"))

# COMMAND ----------

driver_day2_df.createOrReplaceTempView("drivers_day2")

# COMMAND ----------

from pyspark.sql.functions import upper

driver_day3_df=spark.read\
.option("inferschema",True)\
.json("dbfs:/mnt/formula1dlgr/raw/2021-04-18/drivers.json")\
.filter("driverId BETWEEN 1 AND 5 OR driverId BETWEEN 16 AND 20")\
.select("driverId","dob",upper("name.forename").alias("forename"),upper("name.surname").alias("surname"))

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_demo.driver_merge(
# MAGIC   driverId INT,
# MAGIC   dob DATE,
# MAGIC   forename STRING,
# MAGIC   surname STRING,
# MAGIC   createDate DATE,
# MAGIC   updateDate DATE
# MAGIC )
# MAGIC USING DELTA

# COMMAND ----------

# MAGIC %md
# MAGIC Day1

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO f1_demo.driver_merge tgt
# MAGIC USING drivers_day1 upd
# MAGIC ON tgt.driverId = upd.driverId
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     dob = upd.dob,
# MAGIC     forename = upd.forename,
# MAGIC     surname = upd.surname,
# MAGIC     updateDate=current_timestamp
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (
# MAGIC     driverId,
# MAGIC     dob,
# MAGIC     forename,
# MAGIC     surname,
# MAGIC     createDate
# MAGIC   )
# MAGIC   VALUES (
# MAGIC     upd.driverId,
# MAGIC     upd.dob,
# MAGIC     upd.forename,
# MAGIC     upd.surname,
# MAGIC     current_timestamp
# MAGIC   )

# COMMAND ----------

# MAGIC %md
# MAGIC Day2

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO f1_demo.driver_merge tgt
# MAGIC USING drivers_day2 upd
# MAGIC ON tgt.driverId = upd.driverId
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     dob = upd.dob,
# MAGIC     forename = upd.forename,
# MAGIC     surname = upd.surname,
# MAGIC     updateDate=current_timestamp
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (
# MAGIC     driverId,
# MAGIC     dob,
# MAGIC     forename,
# MAGIC     surname,
# MAGIC     createDate
# MAGIC   )
# MAGIC   VALUES (
# MAGIC     upd.driverId,
# MAGIC     upd.dob,
# MAGIC     upd.forename,
# MAGIC     upd.surname,
# MAGIC     current_timestamp
# MAGIC   )

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_demo.driver_merge order by 1 asc

# COMMAND ----------

# MAGIC %md
# MAGIC python

# COMMAND ----------

from delta.tables import *
from pyspark.sql.functions import current_timestamp

deltaTable = DeltaTable.forPath(spark, 'dbfs:/mnt/formula1dlgr/demo/driver_merge')

deltaTable.alias('tgt') \
  .merge(
    driver_day3_df.alias('upd'),
    'tgt.driverId = upd.driverId'
  ) \
  .whenMatchedUpdate(set =
    {
      "driverId": "upd.driverId",
      "dob": "upd.dob",
      "forename": "upd.forename",
      "surname": "upd.surname",
      "updateDate": "current_timestamp()"
    }
  ) \
  .whenNotMatchedInsert(values =
    {
      "driverId": "upd.driverId",
      "dob": "upd.dob",
      "forename": "upd.forename",
      "surname": "upd.surname",
      "createDate":"current_timestamp()"
    }
  ) \
  .execute()

# COMMAND ----------

# MAGIC %md
# MAGIC #####1.History & versioning
# MAGIC #####2.Time travel
# MAGIC #####3.vaccum

# COMMAND ----------

# we can see the History & versioning of the data
%sql
desc history f1_demo.driver_merge

# COMMAND ----------

#by using below sytax we can see data in each version 
%sql
select * 
from f1_demo.driver_merge
version as of 1

# COMMAND ----------

#by using below sytax we can see data in each version by using timestamp
%sql
select * 
from f1_demo.driver_merge
TIMESTAMP as of '2024-06-03T16:07:21.000+00:00'




# COMMAND ----------

#timestamp and pyspark
df=spark.read.format('delta').option("timestampAsOf","2024-06-03T16:15:07.000+00:00").load("dbfs:/mnt/formula1dlgr/demo/driver_merge")
display(df)

# COMMAND ----------

#version and pyspark
df=spark.read.format('delta').option("versionAsOf",0).load("dbfs:/mnt/formula1dlgr/demo/driver_merge")
display(df)

# COMMAND ----------

#by using vacuum command we can deside how many days the history of the data should be there
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
vacuum f1_demo.driver_merge retain 0 hours

# COMMAND ----------

# MAGIC %sql
# MAGIC delete from f1_demo.driver_merge where driverId=1;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_demo.driver_merge

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history f1_demo.driver_merge

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_demo.driver_merge version as of 3

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into f1_demo.driver_merge tgt
# MAGIC using f1_demo.driver_merge version as of 3 src
# MAGIC on tgt.driverId=src.driverId
# MAGIC when not matched then
# MAGIC insert *

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_demo.driver_merge

# COMMAND ----------

# MAGIC %md
# MAGIC #####Transaction Logs

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_demo.driver_txn(
# MAGIC   driverId INT,
# MAGIC   dob DATE,
# MAGIC   forename STRING,
# MAGIC   surname STRING,
# MAGIC   createDate DATE,
# MAGIC   updateDate DATE
# MAGIC )
# MAGIC USING DELTA

# COMMAND ----------

# MAGIC %sql desc history f1_demo.driver_txn
# MAGIC   

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into f1_demo.driver_txn
# MAGIC select * from f1_demo.driver_merge
# MAGIC where driverId=2

# COMMAND ----------

# MAGIC %sql
# MAGIC delete from f1_demo.driver_txn
# MAGIC where driverId=1

# COMMAND ----------

for driver_id in range(3,20):
    spark.sql(f"""insert into f1_demo.driver_txn
        select * from f1_demo.driver_merge
    where driverId={driver_id}""")


# COMMAND ----------

# MAGIC %md
# MAGIC #####Convert parquet to delta

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_demo.driver_convert_to_delta(
# MAGIC   driverId INT,
# MAGIC   dob DATE,
# MAGIC   forename STRING,
# MAGIC   surname STRING,
# MAGIC   createDate DATE,
# MAGIC   updateDate DATE
# MAGIC )
# MAGIC USING PARQUET

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into f1_demo.driver_convert_to_delta
# MAGIC select * from f1_demo.driver_merge

# COMMAND ----------

# MAGIC %sql
# MAGIC CONVERT TO DELTA f1_demo.driver_convert_to_delta

# COMMAND ----------

df=spark.table("f1_demo.driver_convert_to_delta")

# COMMAND ----------

df.write.format("parquet").save("dbfs:/mnt/formula1dlgr/demo/driver_convert_to_delta_new")

# COMMAND ----------

# MAGIC %sql
# MAGIC convert to delta parquet.`/mnt/formula1dlgr/demo/driver_convert_to_delta_new`

# COMMAND ----------

