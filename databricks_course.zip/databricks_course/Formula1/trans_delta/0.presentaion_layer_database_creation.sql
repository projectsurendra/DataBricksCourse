-- Databricks notebook source
create database if not exists f1_presentation
location "/mnt/formula1dlgr/presentation"



-- COMMAND ----------

drop database f1_presentation

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(dbutils.fs.mounts())