# Databricks notebook source
dbutils.widgets.text("p_file_date","2021-03-21")
v_file_date=dbutils.widgets.get("p_file_date")

# COMMAND ----------

# MAGIC %run "../includes/configaration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

display(dbutils.fs.ls(processed_folder_path))

# COMMAND ----------

races_df=spark.read.format("delta").load(f"{processed_folder_path}/races")\
    .withColumnRenamed("name","race_name").withColumnRenamed("race_timestamp","race_date")
display(races_df)

# COMMAND ----------

circutes_df=spark.read.format("delta").load(f"{processed_folder_path}/circutes")\
    .withColumnRenamed("location","circuit_location")
display(circutes_df)

# COMMAND ----------

drivers_df=spark.read.format("delta").load(f"{processed_folder_path}/drivers")\
    .withColumnRenamed("name","driver_name").withColumnRenamed("number","driver_number")\
        .withColumnRenamed("nationality","driver_nationality")
display(drivers_df)

# COMMAND ----------

constuctors_df=spark.read.format("delta").load(f"{processed_folder_path}/constuctors")\
    .withColumnRenamed("name","team")
display(constuctors_df)

# COMMAND ----------

results_df=spark.read.format("delta").load("dbfs:/mnt/formula1dlgr/processed/results/")\
    .withColumnRenamed("time","race_time").withColumnRenamed("race_id","results_race_id").withColumnRenamed("file_date","results_file_date")\
        .filter(f"file_date='{v_file_date}'")
display(results_df)

# COMMAND ----------

before_df=results_df.join(constuctors_df,results_df.constuctor_id == constuctors_df.constuctor_id,"inner")\
    .join(drivers_df,results_df.driver_id == drivers_df.driver_id,"inner")\
        .join(races_df,results_df.results_race_id == races_df.race_id,"inner")
display(before_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

final_df=before_df.join(circutes_df,before_df.circuit_id == circutes_df.circuit_id)\
    .select(before_df.results_file_date,before_df.race_id,before_df.race_year,before_df.race_name,before_df.race_date,before_df.circuit_id,before_df.driver_name,before_df.driver_number,before_df.driver_nationality,before_df.team,before_df.grid,before_df.fastest_lap,before_df.race_time,before_df.points,before_df.position,circutes_df.circuit_location).withColumn("created_date",current_timestamp()).withColumnRenamed("results_file_date","file_date")
display(final_df)

# COMMAND ----------

display(final_df.filter(" race_year == 2020 and race_name == 'Abu Dhabi Grand Prix' ").orderBy(final_df.points.desc()))

# COMMAND ----------

#final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_presentation.race_results")
#overwrite_partition(final_df,"race_id","f1_presentation","race_results")
merge_condition="tgt.race_id=src.race_id AND tgt.driver_name=src.driver_name"
merge_delta_data(final_df,'f1_presentation','race_results',presentation_folder_path,merge_condition,'race_id')

# COMMAND ----------

# MAGIC %sql
# MAGIC select race_id ,count(1)
# MAGIC from f1_presentation.race_results
# MAGIC group by race_id
# MAGIC order by 1 desc