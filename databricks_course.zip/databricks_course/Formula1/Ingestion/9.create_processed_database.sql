-- Databricks notebook source
create database if not exists f1_processed
location "/mnt/formula1dlgr/processed"

-- COMMAND ----------

describe database f1_processed

-- COMMAND ----------

drop database f1_processed cascade