# Databricks notebook source
dbutils.notebook.help()

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
v_data_source=dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_date","2021-03-21")
v_file_date=dbutils.widgets.get("p_file_date")

# COMMAND ----------

#first we have include the required notebooks from includes folder in to this nodebook

# COMMAND ----------

# MAGIC %run "../includes/configaration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Ingest drivers.json.file

# COMMAND ----------

display(dbutils.fs.ls(raw_folder_path))

# COMMAND ----------

# MAGIC %md
# MAGIC ####Step1-Read the JSON file using spark datafrane reader API

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,StringType,IntegerType,DateType

# COMMAND ----------

drivers_schema=StructType([StructField("code",StringType(),True),
                   StructField("dob",DateType(),True),
                   StructField("driverId",IntegerType(),False),
                   StructField("driverRef",StringType(),True),
                   StructField("name",StructType([StructField("forename",StringType(),True),
                                                StructField("surname",StringType(),True)])),
                   StructField("nationality",StringType(),True),
                   StructField("number",IntegerType(),True),
                   StructField("url",StringType(),True)])

# COMMAND ----------

drivers_df=spark.read.schema(drivers_schema).json(f"{raw_folder_path}/{v_file_date}/drivers.json")
display(drivers_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Step2-Rename columns add new columns
# MAGIC   1.driverId to driver_id
# MAGIC   2.driverRef to driver_ref
# MAGIC   3.ingestion date added
# MAGIC   4.name added with concation of forename and surname

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,concat_ws,col,lit

# COMMAND ----------

drivers_with_columns_df1=drivers_df.withColumnRenamed("driverId","driver_id").withColumnRenamed("driverRef","driver_ref")\
                               .withColumn("name",concat_ws(" ",col("name.forename"),col("name.surname"))).withColumn("data_source",lit(v_data_source)).withColumn("file_date",lit(v_file_date))

drivers_with_columns_df=add_ingestion_date(drivers_with_columns_df1)      

# COMMAND ----------

display(drivers_with_columns_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### step3- drop the unwanted columns
# MAGIC

# COMMAND ----------

drivers_final_df=drivers_with_columns_df.drop("url")
display(drivers_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### step4-Write the output to processed container in parrquet format

# COMMAND ----------

drivers_final_df.write.mode("overwrite").format("delta").saveAsTable("f1_processed.drivers")

# COMMAND ----------

# MAGIC %sql
# MAGIC desc table extended f1_processed.drivers

# COMMAND ----------

dbutils.notebook.exit("Success")