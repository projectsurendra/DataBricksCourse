# Databricks notebook source
display(dbutils.fs.mounts())

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlrav/raw"))

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType,DateType,TimestampType

# COMMAND ----------

races_schema=StructType([StructField("raceId",IntegerType(),False),
                         StructField("year",IntegerType(),True),
                         StructField("round",IntegerType(),True),
                         StructField("circuitId",IntegerType(),True),
                         StructField("name",StringType(),True),
                         StructField("date",DateType(),True),
                         StructField("time",StringType(),True),
                         StructField("url",StringType(),True)])

# COMMAND ----------

races_df=spark.read.option("header",True).schema(races_schema).csv("/mnt/formula1dlrav/raw/races.csv")

# COMMAND ----------

races_df.show()

# COMMAND ----------

races_drop_df=races_df.drop("url")

# COMMAND ----------

races_drop_df.show()

# COMMAND ----------

races_renamed_df=races_drop_df.withColumnRenamed("raceId","race_id").withColumnRenamed("year","race_year")\
                 .withColumnRenamed("circuitId","circuit_id")

# COMMAND ----------

races_renamed_df.show()

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

race_ingest_df=races_renamed_df.withColumn("ingestion_date",current_timestamp())
race_ingest_df.show()

# COMMAND ----------

from pyspark.sql.functions import to_timestamp,concat_ws,col

# COMMAND ----------

race_concat_final_df=race_ingest_df.withColumn("race_timestamp",to_timestamp(concat_ws(" ",col("date"),col("time")),'yyyy-MM-dd HH:mm:ss')).drop("date","time")
race_concat_final_df.show()