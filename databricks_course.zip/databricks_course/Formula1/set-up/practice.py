# Databricks notebook source
display(dbutils.fs.mounts())

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlrav/raw"))

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType,DoubleType

# COMMAND ----------

circuits_schema=StructType(fields=[StructField("circuitId",IntegerType(),False),
                                   StructField("circuitRef",StringType(),True),
                                   StructField("name",StringType(),True),
                                   StructField("location",StringType(),True),
                                   StructField("country",StringType(),True),
                                   StructField("lat",DoubleType(),True),
                                   StructField("lng",DoubleType(),True),
                                   StructField("alt",DoubleType(),True),
                                   StructField("url",StringType(),True)])

# COMMAND ----------



# COMMAND ----------

df=spark.read.option("header",True).schema(circuits_schema).csv("dbfs:/mnt/formula1dlrav/raw/circuits.csv")

# COMMAND ----------

df.show()

# COMMAND ----------

df.printSchema()