# Databricks notebook source
# MAGIC %md
# MAGIC ### Access Azure Data Lake using Service Pricipal secrets
# MAGIC #### Steps to follow(before come to this steps first you have service principle add this to storege account and add clientid,tenantid and secrete to key vault )
# MAGIC 1.get client_id,tenant_id and client_secret from key vault
# MAGIC 2.set spark conf with app/client id,directory/tenant id and secrete
# MAGIC 3.List file from the demo container 
# MAGIC 4.Read data from circuits.csv file

# COMMAND ----------

dbutils.secrets.help()

# COMMAND ----------

dbutils.secrets.listScopes()

# COMMAND ----------

dbutils.secrets.list(scope='formula1-scope')

# COMMAND ----------

client_id_secrets=dbutils.secrets.get(scope='formula1-scope',key='formula1dlrav-account-service-pricipal-client-id-secrets')
tenant_id_secrets=dbutils.secrets.get(scope='formula1-scope',key='formula1dlrav-account-service-pricipal-tenant-id-secrets')
client_secret_secrets=dbutils.secrets.get(scope='formula1-scope',key='formula1dlrav-account-service-pricipal-client-secret')

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.formula1dlravi.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.formula1dlravi.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.formula1dlravi.dfs.core.windows.net", client_id_secrets)
spark.conf.set("fs.azure.account.oauth2.client.secret.formula1dlravi.dfs.core.windows.net", client_secret_secrets)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.formula1dlravi.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id_secrets}/oauth2/token")

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlravi.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1dlravi.dfs.core.windows.net/circuits.csv"))