# Databricks notebook source
# MAGIC %md
# MAGIC #### Access Azure Deta Lake using SAS Token
# MAGIC 1.Set the spark config for SAS Token
# MAGIC 2.List file from the demo container
# MAGIC 3.Read data from circuits.csv file

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.formula1dlravi.dfs.core.windows.net","SAS")
spark.conf.set("fs.azure.sas.token.provider.type.formula1dlravi.dfs.core.windows.net","org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")
spark.conf.set("fs.azure.sas.fixed.token.formula1dlravi.dfs.core.windows.net","sp=rwl&st=2024-04-23T15:51:04Z&se=2024-04-23T23:51:04Z&spr=https&sv=2022-11-02&sr=c&sig=fMqmG2ZSOFeone5R%2Bp0c9tVcooaCD6L%2BT0UD8oXZYjE%3D")

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlravi.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1dlravi.dfs.core.windows.net/circuits.csv"))