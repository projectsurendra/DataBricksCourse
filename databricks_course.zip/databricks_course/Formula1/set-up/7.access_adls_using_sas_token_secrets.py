# Databricks notebook source
# MAGIC %md
# MAGIC #### Access Azure Deta Lake using SAS Token Secrets
# MAGIC 1.Set the spark config for SAS Token secret
# MAGIC 2.List file from the demo container
# MAGIC 3.Read data from circuits.csv file

# COMMAND ----------

dbutils.secrets.help()

# COMMAND ----------

dbutils.secrets.listScopes()

# COMMAND ----------

dbutils.secrets.list(scope='formula1-scope')

# COMMAND ----------

SAS_secrets=dbutils.secrets.get(scope='formula1-scope',key='formula1dlravi-account-SASToken-secrets')

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.formula1dlravi.dfs.core.windows.net","SAS")
spark.conf.set("fs.azure.sas.token.provider.type.formula1dlravi.dfs.core.windows.net","org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")
spark.conf.set("fs.azure.sas.fixed.token.formula1dlravi.dfs.core.windows.net",SAS_secrets)

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlravi.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1dlravi.dfs.core.windows.net/circuits.csv"))