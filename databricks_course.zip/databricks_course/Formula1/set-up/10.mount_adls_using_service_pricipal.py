# Databricks notebook source
# MAGIC %md
# MAGIC ### Access Azure Data Lake using Service Pricipal secrets
# MAGIC #### Steps to follow
# MAGIC 1.get client_id,tenant_id and client_secrets from key voult
# MAGIC 2.set spark config with app/client id,directory/tenant id & secrete
# MAGIC 3.call files system utility mount to mount storage
# MAGIC 4.explore other file system utilities related to mount(list all mount,unmount)

# COMMAND ----------

dbutils.secrets.help()

# COMMAND ----------

dbutils.secrets.listScopes()

# COMMAND ----------

dbutils.secrets.list(scope='formul1-scope')

# COMMAND ----------

client_id_secrets=dbutils.secrets.get(scope='formul1-scope',key='formula1dlgr-account-service-pricipal-client-id-secrets')
tenant_id_secrets=dbutils.secrets.get(scope='formul1-scope',key='formula1dlgr-account-service-pricipal-tenant-id-secrets')
client_secret_secrets=dbutils.secrets.get(scope='formul1-scope',key='formula1dlgr-account-service-pricipal-client-secret')

# COMMAND ----------

configs = {"fs.azure.account.auth.type":"OAuth",
           "fs.azure.account.oauth.provider.type":"org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id":client_id_secrets,
           "fs.azure.account.oauth2.client.secret":client_secret_secrets,
           "fs.azure.account.oauth2.client.endpoint":f"https://login.microsoftonline.com/{tenant_id_secrets}/oauth2/token"}

# COMMAND ----------

# Optionally, you can add <directory-name> to the source URI of your mount point.
dbutils.fs.mount(
  source = "abfss://demo@formula1dlgr.dfs.core.windows.net/",
  mount_point = "/mnt/formula1dlgr/demo",
  extra_configs = configs)

# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://presentation@formula1dlgr.dfs.core.windows.net/",
  mount_point = "/mnt/formula1dlgr/presentation",
  extra_configs = configs)

# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://processed@formula1dlgr.dfs.core.windows.net/",
  mount_point = "/mnt/formula1dlgr/processed",
  extra_configs = configs)

# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://raw@formula1dlgr.dfs.core.windows.net/",
  mount_point = "/mnt/formula1dlgr/raw",
  extra_configs = configs)

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlgr/raw"))

# COMMAND ----------

display(spark.read.csv("dbfs:/mnt/formula1dlravi/demo/circuits.csv"))

# COMMAND ----------

# How find all mounts in workspace
display(dbutils.fs.mounts())


# COMMAND ----------

# How to remove the mount
dbutils.fs.unmount("/mnt/formula1dlravi/presentation")