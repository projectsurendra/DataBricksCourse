# Databricks notebook source
#Before that we have to create Azure key voult,secrete scope and client_id,tenant_id,client_secret into Azure key voult

#Access Azure Deta Lake using service principle secrets
#Step1:first we have find to Scope and Value
dbutils.secrets.help() #it gives the all the function reqired to get Scope and Value
display(dbutils.secrets.listScopes()) #it gives the list of scopes
display(dbutils.secrets.list(scope='formula1dlrav-scope')) #ts gives the list of Keys

client_id_secrets=dbutils.secrets.get(scope='formula1dlrav-scope',key='formula1dlrav-account-service-pricipal-client-id-secrets')
tenant_id_secrets=dbutils.secrets.get(scope='formula1dlrav-scope',key='formula1dlrav-account-service-pricipal-tenant-id-secrets')
client_secret_secrets=dbutils.secrets.get(scope='formula1dlrav-scope',key='formula1dlrav-account-service-pricipal-client-secret')
#we will above client_id_secrets,tenant_id_secrets,client_secret_secrets in place of client_id,tenant_id,client_secret

#Step2:we have configure and authenticate ADLS from the notebook with with client_id,tenant_id,client_secret(assigned variable)
#SYNTAX:configs = {"fs.azure.account.auth.type": "OAuth",
         # "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
         # "fs.azure.account.oauth2.client.id": "<application-id>",
          #"fs.azure.account.oauth2.client.secret": dbutils.secrets.get(scope="<scope-name>",key="<service-credential-key-name>"),
         # "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/<directory-id>/oauth2/token"}

configs = {"fs.azure.account.auth.type":"OAuth",
           "fs.azure.account.oauth.provider.type":"org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id":client_id_secrets,
           "fs.azure.account.oauth2.client.secret":client_secret_secrets,
           "fs.azure.account.oauth2.client.endpoint":f"https://login.microsoftonline.com/{tenant_id_secrets}/oauth2/token"}

#step3:# Optionally, you can add <directory-name> to the source URI of your mount point.
#SYNTAX:dbutils.fs.mount(
          #source = "abfss://<container-name>@<storage-account-name>.dfs.core.windows.net/",
          #mount_point = "/mnt/<mount-name>",
          #extra_configs = configs)
dbutils.fs.mount(
  source = "abfss://demo@formula1dlrav.dfs.core.windows.net/",
  mount_point = "/mnt/formula1dlrav/demo",
  extra_configs = configs)
