# Databricks notebook source
display(dbutils.fs.mounts())

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlravi/raw"))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### step1:Read multiline the json file by using spark reader API

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType,TimestampType

# COMMAND ----------

pit_stops_schema=StructType([StructField("raceId",IntegerType(),False),
                             StructField("driverId",IntegerType(),True),
                             StructField("stop",StringType(),True),
                             StructField("lap",IntegerType(),True),
                             StructField("time",StringType(),True),
                             StructField("duration",StringType(),True),
                             StructField("milliseconds",IntegerType(),True)])

# COMMAND ----------

pit_stops_df=spark.read.schema(pit_stops_schema).option("multiLine",True).json("/mnt/formula1dlravi/raw/pit_stops.json")
display(pit_stops_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #######Step2:Rename columns and add new columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

final_pit_stops_df=pit_stops_df.withColumnRenamed("driverId","driver_id").withColumnRenamed("raceId","race_id")\
            .withColumn("ingestion_date",current_timestamp())
display(final_pit_stops_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ########Stpe3:write to the output data to the processed container inparquet format

# COMMAND ----------

final_pit_stops_df.write.mode("overwrite").parquet("/mnt/formula1dlravi/processed/pit_stops")