# Databricks notebook source
# MAGIC %md
# MAGIC ### Ingest drivers.json.file

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlravi/raw"))

# COMMAND ----------

# MAGIC %md
# MAGIC ####Step1-Read the JSON file using spark datafrane reader API

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,StringType,IntegerType,DateType

# COMMAND ----------

drivers_schema=StructType([StructField("code",StringType(),True),
                   StructField("dob",DateType(),True),
                   StructField("driverId",IntegerType(),False),
                   StructField("driverRef",StringType(),True),
                   StructField("name",StructType([StructField("forename",StringType(),True),
                                                StructField("surname",StringType(),True)])),
                   StructField("nationality",StringType(),True),
                   StructField("number",IntegerType(),True),
                   StructField("url",StringType(),True)])

# COMMAND ----------

drivers_df=spark.read.schema(drivers_schema).json("/mnt/formula1dlravi/raw/drivers.json")
display(drivers_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Step2-Rename columns add new columns
# MAGIC   1.driverId to driver_id
# MAGIC   2.driverRef to driver_ref
# MAGIC   3.ingestion date added
# MAGIC   4.name added with concation of forename and surname

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,concat_ws,col

# COMMAND ----------

drivers_with_columns_df=drivers_df.withColumnRenamed("driverId","driver_id").withColumnRenamed("driverRef","driver_ref")\
                               .withColumn("ingestion_date",current_timestamp())\
                               .withColumn("name",concat_ws(" ",col("name.forename"),col("name.surname")))
          

# COMMAND ----------

display(drivers_with_columns_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### step3- drop the unwanted columns
# MAGIC

# COMMAND ----------

drivers_final_df=drivers_with_columns_df.drop("url")
display(drivers_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### step4-Write the output to processed container in parrquet format

# COMMAND ----------

drivers_final_df.write.mode("overwrite").parquet("/mnt/formula1dlravi/processed/drivers")