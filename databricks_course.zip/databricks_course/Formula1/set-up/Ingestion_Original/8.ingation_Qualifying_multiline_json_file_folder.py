# Databricks notebook source
display(dbutils.fs.mounts())

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlravi/raw"))

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step1:Read the folder which cantains the multiline json file using the spark reader API

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType

# COMMAND ----------

qualifying_schema=StructType([StructField("qualifyId",IntegerType(),False),
                              StructField("raceId",IntegerType(),True),
                              StructField("driverId",IntegerType(),True),
                              StructField("constructorId",IntegerType(),True),
                              StructField("number",IntegerType(),True),
                              StructField("position",IntegerType(),True),
                              StructField("q1",StringType(),True),
                              StructField("q2",StringType(),True),
                              StructField("q3",StringType(),True)])

# COMMAND ----------

qualifiying_df=spark.read.option("multiLine",True).schema(qualifying_schema).json("/mnt/formula1dlravi/raw/qualifying/*.json")
display(qualifiying_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Step2:Rename and add the new columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

qualifiying_final_df=qualifiying_df.withColumnRenamed("qualifyId","qualify_id").withColumnRenamed("raceId","race_id")\
                                   .withColumnRenamed("driverId","driver_id").withColumnRenamed("constructorId","constructor_id")\
                                   .withColumn("ingestion_date",current_timestamp())
display(qualifiying_final_df)  
    

# COMMAND ----------

# MAGIC %md
# MAGIC ######step3:write to out put to processed container in parquet format

# COMMAND ----------

qualifiying_final_df.write.mode("overwrite").parquet("/mnt/formula1dlravi/processed/qualifying")