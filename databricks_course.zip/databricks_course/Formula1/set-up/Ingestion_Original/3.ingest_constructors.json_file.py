# Databricks notebook source
display(dbutils.fs.mounts())

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlravi/raw"))

# COMMAND ----------

# MAGIC %md
# MAGIC Step1:Read the json file using the spark dataframe reader

# COMMAND ----------

constuctor_schema="constructorId INT,constructorRef STRING, name STRING,nationality STRING,url STRING"

# COMMAND ----------

constrctors_df=spark.read.schema(constuctor_schema).json("/mnt/formula1dlravi/raw/constructors.json")
constrctors_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Step2-drop unwanted columns from dataframe

# COMMAND ----------

constuctor_dropped_df=constrctors_df.drop("url")
constuctor_dropped_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Step3-Rename columns and add ingestion date

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

constoctor_final_df=constuctor_dropped_df.withColumnRenamed("constructorId","constuctor_id")\
                      .withColumnRenamed("constructorRef","constructor_ref")\
                      .withColumn("ingestion_time",current_timestamp())

# COMMAND ----------

constoctor_final_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Step4-Write out put to parquet file

# COMMAND ----------

constoctor_final_df.write.mode("overwrite").parquet("/mnt/formula1dlravi/processed/constuctors")

# COMMAND ----------

# MAGIC %md
# MAGIC