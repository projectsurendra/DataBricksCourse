# Databricks notebook source
# MAGIC %md
# MAGIC ### Ingest circuits.csv.files

# COMMAND ----------

# MAGIC %md
# MAGIC #### step1-Read the csv file by using spark dataframe reader

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlravi/raw"))

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType,DoubleType

# COMMAND ----------

circuits_schema=StructType(fields=[StructField("circuitId",IntegerType(),False),
                                   StructField("circuitRef",StringType(),True),
                                   StructField("name",StringType(),True),
                                   StructField("location",StringType(),True),
                                   StructField("country",StringType(),True),
                                   StructField("lat",DoubleType(),True),
                                   StructField("lng",DoubleType(),True),
                                   StructField("alt",DoubleType(),True),
                                   StructField("url",StringType(),True)])

# COMMAND ----------

circuits_df=spark.read.option("header",True).schema(circuits_schema).csv("/mnt/formula1dlravi/raw/circuits.csv")



# COMMAND ----------

circuits_df.show(30)

# COMMAND ----------

circuits_df.printSchema()

# COMMAND ----------

circuits_df.describe().show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step2- select only the required columns

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

circuits_selected_df=circuits_df.select(col("circuitId"),col("circuitRef"),col("name"),col("location"),col("country"),col("lat"),col("lng"),col("alt"))

# COMMAND ----------

circuits_selected_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ####Step3-Rename the columns as required

# COMMAND ----------

circuits_renamed_df=circuits_selected_df.withColumnRenamed("circuitId","circuit_id").withColumnRenamed("circuitRef","circuit_ref")\
                    .withColumnRenamed("lat","lattitude")\
                        .withColumnRenamed("lng","longitute").withColumnRenamed("alt","altitude")

# COMMAND ----------

circuits_renamed_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step4-Add Ingestion data to the dataframe

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

circutis_final_df=circuits_renamed_df.withColumn("ingestion_date",current_timestamp())

# COMMAND ----------

circutis_final_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ####Step5-write the data to datalake as parquet

# COMMAND ----------

circutis_final_df.write.mode("overwrite").parquet("/mnt/formula1dlravi/processed/circutes")

# COMMAND ----------

display(spark.read.parquet("/mnt/formula1dlravi/processed/circutes"))