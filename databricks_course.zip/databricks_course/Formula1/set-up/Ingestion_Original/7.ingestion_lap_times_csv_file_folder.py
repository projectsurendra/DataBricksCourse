# Databricks notebook source
display(dbutils.fs.mounts())

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlravi/raw"))

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step1:Read the folder which cantains the csv file using the spark reader API

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType

# COMMAND ----------

lap_times_schem=StructType([StructField("raceId",IntegerType(),False),
                           StructField("driverId",IntegerType(),True),
                           StructField("lap",IntegerType(),True),
                           StructField("postion",IntegerType(),True),
                           StructField("time",StringType(),True),
                           StructField("milliseconds",IntegerType(),True)])

# COMMAND ----------

lap_times_df=spark.read.schema(lap_times_schem).csv("dbfs:/mnt/formula1dlravi/raw/lap_times/")
display(lap_times_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Step2:Rename and add the new columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

lap_times_final_df = lap_times_df.withColumnRenamed("driverId","driver_id").withColumnRenamed("raceId","race_id").withColumn("ingestion_time",current_timestamp())
display(lap_times_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ######step3:write to out put to processed container in parquet format

# COMMAND ----------

lap_times_final_df.write.mode("overwrite").parquet("/mnt/formula1dlravi/processed/laptimes")

# COMMAND ----------

display(spark.read.parquet("/mnt/formula1dlravi/processed/laptimes"))