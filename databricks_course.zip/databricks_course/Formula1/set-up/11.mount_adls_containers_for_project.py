# Databricks notebook source
# MAGIC %md
# MAGIC ### Mount Azure Data Lake Containers for the Project
# MAGIC

# COMMAND ----------

def mount_adls(storage_account_name,container_name):

    # Get cecrets from key vault
    client_id_secrets=dbutils.secrets.get(scope='formula1-scope',key='formula1dlrav-account-service-pricipal-client-id-secrets')
    tenant_id_secrets=dbutils.secrets.get(scope='formula1-scope',key='formula1dlrav-account-service-pricipal-tenant-id-secrets')
    client_secret_secrets=dbutils.secrets.get(scope='formula1-scope',key='formula1dlrav-account-service-pricipal-client-secret')
    
    # Set Spark Configarations
    configs = {"fs.azure.account.auth.type":"OAuth",
           "fs.azure.account.oauth.provider.type":"org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id":client_id_secrets,
           "fs.azure.account.oauth2.client.secret":client_secret_secrets,
           "fs.azure.account.oauth2.client.endpoint":f"https://login.microsoftonline.com/{tenant_id_secrets}/oauth2/token"}
    #Unmount the mount point if it already exists
    if any(mount.mountPoint == f"/mnt/{storage_account_name}/{container_name}" for mount in dbutils.fs.mounts()):
        dbutils.fs.unmount(f"/mnt/{storage_account_name}/{container_name}")
       

    # Mount the storahe account container
    dbutils.fs.mount(
      source = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/",
      mount_point = f"/mnt/{storage_account_name}/{container_name}",
      extra_configs = configs)
    print("Mount Got Created")
    
    display(dbutils.fs.mounts())


# COMMAND ----------

mount_adls('formula1dlravi','presentation')

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlravi/demo"))

# COMMAND ----------

display(spark.read.csv("dbfs:/mnt/formula1dlravi/demo/circuits.csv"))