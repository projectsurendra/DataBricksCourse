# Databricks notebook source
display(dbutils.fs.mounts())

# COMMAND ----------

display(dbutils.fs.ls("/mnt/formula1dlrav/raw"))

# COMMAND ----------

display(spark.read.csv("dbfs:/mnt/formula1dlrav/raw/circuits.csv"))