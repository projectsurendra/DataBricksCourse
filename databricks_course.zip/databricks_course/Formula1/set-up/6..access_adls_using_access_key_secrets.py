# Databricks notebook source
# MAGIC %md
# MAGIC #### Access Azure Deta Lake using access keys secrets
# MAGIC 1.Set the spark conf fs.azure.account.key with secrets
# MAGIC 2.List file from the demo container
# MAGIC 3.Read data from circuits.csv file

# COMMAND ----------

dbutils.secrets.help()

# COMMAND ----------

dbutils.secrets.listScopes()

# COMMAND ----------

dbutils.secrets.list(scope='formula1-scope')

# COMMAND ----------

formula1dlrav_account_access_key=dbutils.secrets.get(scope='formula1-scope',key='formula1dlravi-account-access-key')

# COMMAND ----------

spark.conf.set(
    "fs.azure.account.key.formula1dlravi.dfs.core.windows.net",formula1dlrav_account_access_key)

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlravi.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1dlravi.dfs.core.windows.net/circuits.csv"))