# Databricks notebook source
# MAGIC %md
# MAGIC ### Access Azure Data Lake using Service Pricipal
# MAGIC #### Steps to follow
# MAGIC 1.Registar the Azure Active Directory Application/ Service Principal
# MAGIC 2.Generate a secret/password for the Application
# MAGIC 3.set the spark configaration with app/ ClientId,Directory/Tenant Id & Secret
# MAGIC 4.Assign the role 'Storage Blob Deta Contributor' to the Data Lake

# COMMAND ----------

client_id="c92f68ec-bb52-43d0-b032-369d7e0f1a19"
tenant_id="fe88de78-d953-4b95-9dba-28ef72395b94"
client_secret="NRY8Q~uWARjrxEVUWl15yf151Y~P5e1DZufyXbGB"

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.formula1dlravi.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.formula1dlravi.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.formula1dlravi.dfs.core.windows.net", client_id)
spark.conf.set("fs.azure.account.oauth2.client.secret.formula1dlravi.dfs.core.windows.net", client_secret)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.formula1dlravi.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlravi.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1dlravi.dfs.core.windows.net/circuits.csv"))