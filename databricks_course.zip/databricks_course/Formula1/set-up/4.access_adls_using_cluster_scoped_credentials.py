# Databricks notebook source
# MAGIC %md
# MAGIC #### Access Azure Deta Lake using cluster scoped credentials
# MAGIC 1.Set the spark conf fs.azure.account.key in cluster
# MAGIC 2.List file from the demo container
# MAGIC 3.Read data from circuits.csv file

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dlravi.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1dlravi.dfs.core.windows.net/circuits.csv"))