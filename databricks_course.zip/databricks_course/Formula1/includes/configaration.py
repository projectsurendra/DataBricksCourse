# Databricks notebook source
raw_folder_path="/mnt/formula1dlgr/raw"
processed_folder_path="/mnt/formula1dlgr/processed"
presentation_folder_path="/mnt/formula1dlgr/presentation"

# COMMAND ----------

#If your using mounts(students subscription)we have to use like below
#raw_folder_path="abfss://raw@formula1dlrav.dfs.core.windows.net"
#processed_folder_path="abfss://processed@formula1dlrav.dfs.core.windows.net"
#presentation_folder_path="abfss://presentation@formula1dlrav.dfs.core.windows.net"