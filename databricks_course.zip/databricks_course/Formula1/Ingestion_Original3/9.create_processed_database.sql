-- Databricks notebook source
create database if not exists f1_processed
location "/mnt/formula1dlravi/processed"

-- COMMAND ----------

describe database f1_processed