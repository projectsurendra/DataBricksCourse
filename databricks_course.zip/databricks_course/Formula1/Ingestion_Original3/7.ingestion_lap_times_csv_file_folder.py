# Databricks notebook source
dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
v_data_source=dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_date","2021-03-28")
v_file_date=dbutils.widgets.get("p_file_date")

# COMMAND ----------

#first we have include the required notebooks from includes folder in to this nodebook

# COMMAND ----------

# MAGIC %run "../includes/configaration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

display(dbutils.fs.ls(raw_folder_path))

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step1:Read the folder which cantains the csv file using the spark reader API

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType

# COMMAND ----------

lap_times_schem=StructType([StructField("raceId",IntegerType(),False),
                           StructField("driverId",IntegerType(),True),
                           StructField("lap",IntegerType(),True),
                           StructField("postion",IntegerType(),True),
                           StructField("time",StringType(),True),
                           StructField("milliseconds",IntegerType(),True)])

# COMMAND ----------

lap_times_df=spark.read.schema(lap_times_schem).csv(f"{raw_folder_path}/{v_file_date}/lap_times/")
display(lap_times_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Step2:Rename and add the new columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,lit

# COMMAND ----------

lap_times_final_df1 = lap_times_df.withColumnRenamed("driverId","driver_id").withColumnRenamed("raceId","race_id").withColumn("data_source",lit(v_data_source)).withColumn("file_date",lit(v_file_date))
lap_times_final_df=add_ingestion_date(lap_times_final_df1)
display(lap_times_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ######step3:write to out put to processed container in parquet format

# COMMAND ----------

# MAGIC %md
# MAGIC ####method1

# COMMAND ----------

# for race_id_list in lap_times_final_df.select("race_id").distinct().collect():
#   if(spark._jsparkSession.catalog().tableExists("f1_processed.laptimes")):
#     spark.sql(f"alter table f1_processed.laptimes drop if exists partition(race_id={race_id_list.race_id})")

# COMMAND ----------

#lap_times_final_df.write.mode("append").partitionBy("race_id").format("parquet").saveAsTable("f1_processed.laptimes")

# COMMAND ----------

# MAGIC %md
# MAGIC ####method2

# COMMAND ----------

spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")

# COMMAND ----------

lap_times_final_df=lap_times_final_df.select('driver_id','lap','postion','time','milliseconds','data_source','file_date',
'ingestion_date','race_id')

# COMMAND ----------

if(spark._jsparkSession.catalog().tableExists("f1_processed.laptimes")):
    lap_times_final_df.write.mode("overwrite").insertInto("f1_processed.laptimes")
else:
    lap_times_final_df.write.mode("overwrite").partitionBy("race_id").format("parquet").saveAsTable("f1_processed.laptimes")

# COMMAND ----------

# MAGIC %md
# MAGIC #####method3

# COMMAND ----------

# #by using function which created by us
# overwrite_partition(lap_times_final_df,"race_id","f1_processed","laptimes")

# COMMAND ----------

dbutils.notebook.exit("Success")

# COMMAND ----------

# MAGIC %sql
# MAGIC select race_id ,count(1)
# MAGIC from f1_processed.laptimes
# MAGIC group by race_id
# MAGIC order by race_id desc

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table f1_processed.laptimes