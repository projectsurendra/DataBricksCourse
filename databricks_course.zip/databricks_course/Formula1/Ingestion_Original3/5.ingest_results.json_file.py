# Databricks notebook source
dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
v_data_source=dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_date","2021-03-28")
v_file_date=dbutils.widgets.get("p_file_date")

# COMMAND ----------

v_file_date

# COMMAND ----------

#first we have include the required notebooks from includes folder in to this nodebook

# COMMAND ----------

# MAGIC %run "../includes/configaration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

display(dbutils.fs.ls(raw_folder_path))

# COMMAND ----------

# MAGIC %md
# MAGIC ######step1:Read the json file using the spark dataframe reader API

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType,FloatType

# COMMAND ----------

result_schema=StructType([StructField("resultId",IntegerType(),False),
                   StructField("raceId",IntegerType(),True),
                   StructField("driverId",IntegerType(),True),
                   StructField("constructorId",IntegerType(),True),
                   StructField("number",IntegerType(),True),
                   StructField("grid",IntegerType(),True),
                   StructField("position",IntegerType(),True),
                   StructField("positionText",StringType(),True),
                   StructField("positionOrder",IntegerType(),True),
                   StructField("points",FloatType(),True),
                   StructField("laps",IntegerType(),True),
                   StructField("time",StringType(),True),
                   StructField("milliseconds",IntegerType(),True),
                   StructField("fastestLap",IntegerType(),True),
                   StructField("rank",IntegerType(),True),
                   StructField("fastestLapTime",StringType(),True),
                   StructField("FastestLapSpeed",StringType(),True),
                   StructField("statusId",IntegerType(),True)])

# COMMAND ----------

results_df=spark.read.schema(result_schema).json(f"{raw_folder_path}/{v_file_date}/results.json")
display(results_df)
results_df.printSchema

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step2:drop the unwanted columns

# COMMAND ----------

results_drop_df=results_df.drop("statusId")
display(results_drop_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step3:Rename columns

# COMMAND ----------


from pyspark.sql.functions import lit

# COMMAND ----------

results_renamed_df=results_drop_df.withColumnRenamed("resultId","result_id").withColumnRenamed("raceId","race_id")\
    .withColumnRenamed("driverId","driver_id").withColumnRenamed("constructorId","constuctor_id")\
        .withColumnRenamed("positionText","position_text").withColumnRenamed("positionOrder","position_order")\
            .withColumnRenamed("fastestLap","fastest_lap").withColumnRenamed("fastestLapTime","fastest_lap_time")\
                .withColumnRenamed("FastestLapSpeed","fastest_lap_speed").withColumn("data_source",lit(v_data_source)).withColumn("file_date",lit(v_file_date))
display(results_renamed_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step4:add the column

# COMMAND ----------

result_final_df=add_ingestion_date(results_renamed_df)
display(result_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step5:write to output to processed container in parquet format

# COMMAND ----------

# MAGIC %md
# MAGIC #####method1

# COMMAND ----------

# #by using the below code we can restrict the duplicate entries of partition colunm while executing every time
# for race_id_list in result_final_df.select("race_id").distinct().collect():
#     if(spark._jsparkSession.catalog().tableExists("f1_processed.results")):
#         spark.sql(f"alter table f1_processed.results drop if exists partition (race_id={race_id_list.race_id})")

# COMMAND ----------

# #in incremental load methon we have to write the data into table like below
# result_final_df.write.mode("append").partitionBy("race_id").format("parquet").saveAsTable("f1_processed.results")

# COMMAND ----------

# MAGIC %md
# MAGIC #####method2

# COMMAND ----------

#to set the partition overwrite is dynamic we have to use blow code
spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")

# COMMAND ----------

#we are making last race_id as last column
result_final_df=result_final_df.select("result_id","driver_id","constuctor_id","number","grid","position","position_text","position_order","points","laps","time","milliseconds","fastest_lap","rank","fastest_lap_time","fastest_lap_speed","data_source","file_date","race_id")

# COMMAND ----------

display(result_final_df)

# COMMAND ----------

#if you want to use the below code for that we have make the partition column at last to the dataframe for insertion purpose
#to work this code properlly means we have make partition overwrite mode should be dynamic(defalut is static) for insertion purpose
if(spark._jsparkSession.catalog().tableExists("f1_processed.results")):
    result_final_df.write.mode("overwrite").insertInto("f1_processed.results")
else:
    result_final_df.write.mode("overwrite").partitionBy("race_id").format("parquet").saveAsTable("f1_processed.results")

# COMMAND ----------

#if first we are writing the data into table(creating table) means we have to use below code
#result_final_df.write.mode("overwrite").partitionBy("race_id").format("parquet").saveAsTable("f1_processed.results")

# COMMAND ----------

#after create the table we can use the below code to insert the data into table
#result_final_df.write.mode("overwrite").insertInto("f1_processed.results")

# COMMAND ----------

# MAGIC %sql
# MAGIC select race_id,count(1)
# MAGIC from f1_processed.results
# MAGIC group by race_id
# MAGIC order by 1 desc

# COMMAND ----------

dbutils.notebook.exit("Success")

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table f1_processed.results