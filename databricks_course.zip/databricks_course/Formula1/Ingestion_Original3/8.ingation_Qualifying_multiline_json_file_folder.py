# Databricks notebook source
dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
v_data_source=dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_date","2021-03-28")
v_file_date=(dbutils.widgets.get("p_file_date"))

# COMMAND ----------

#first we have include the required notebooks from includes folder in to this nodebook

# COMMAND ----------

# MAGIC %run "../includes/configaration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

display(dbutils.fs.ls(raw_folder_path))

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step1:Read the folder which cantains the multiline json file using the spark reader API

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType

# COMMAND ----------

qualifying_schema=StructType([StructField("qualifyId",IntegerType(),False),
                              StructField("raceId",IntegerType(),True),
                              StructField("driverId",IntegerType(),True),
                              StructField("constructorId",IntegerType(),True),
                              StructField("number",IntegerType(),True),
                              StructField("position",IntegerType(),True),
                              StructField("q1",StringType(),True),
                              StructField("q2",StringType(),True),
                              StructField("q3",StringType(),True)])

# COMMAND ----------

qualifiying_df=spark.read.option("multiLine",True).schema(qualifying_schema).json(f"{raw_folder_path}/{v_file_date}/*.json")
display(qualifiying_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Step2:Rename and add the new columns

# COMMAND ----------

from pyspark.sql.functions import lit

# COMMAND ----------

qualifiying_final_df1=qualifiying_df.withColumnRenamed("qualifyId","qualify_id").withColumnRenamed("raceId","race_id")\
                                   .withColumnRenamed("driverId","driver_id").withColumnRenamed("constructorId","constructor_id").withColumn("data_source",lit(v_data_source)).withColumn("file_date",lit(v_file_date))
qualifiying_final_df=add_ingestion_date(qualifiying_final_df1)                             
display(qualifiying_final_df)  
    

# COMMAND ----------

# MAGIC %md
# MAGIC ######step3:write to out put to processed container in parquet format

# COMMAND ----------

# MAGIC %md
# MAGIC ####method1

# COMMAND ----------

# for race_id_list in qualifiying_final_df.select("race_id").distinct().collect():
#     if(spark._jsparkSession.catalog().tableExists("f1_processed.qualifying")):
#         spark.sql(f"alter table f1_processed.qualifying drop if exists partition(race_id='{race_id_list.race_id}')")

# COMMAND ----------

#qualifiying_final_df.write.mode("append").partitionBy("race_id").format("parquet").saveAsTable("f1_processed.qualifying")

# COMMAND ----------

# MAGIC %md
# MAGIC ####method2

# COMMAND ----------

#spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")

# COMMAND ----------

#qualifiying_final_df=qualifiying_final_df.select('qualify_id','driver_id','constructor_id','number','position','q1','q2','q3',
#'data_source','file_date','ingestion_date','race_id')

# COMMAND ----------

# if(spark._jsparkSession.catalog().tableExists("f1_processed.qualifying")):
#     qualifiying_final_df.write.mode("overwrite").insertInto("f1_processed.qualifying")
# else:
#     qualifiying_final_df.write.mode("overwrite").partitionBy("race_id").format("parquet").saveAsTable("f1_processed.qualifying")

# COMMAND ----------

overwrite_partition(qualifiying_final_df,"race_id","f1_processed","qualifying")

# COMMAND ----------

dbutils.notebook.exit("Success")

# COMMAND ----------

# MAGIC %sql
# MAGIC select race_id,count(1)
# MAGIC from f1_processed.qualifying
# MAGIC group by race_id
# MAGIC order by 1 desc

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table f1_processed.qualifying