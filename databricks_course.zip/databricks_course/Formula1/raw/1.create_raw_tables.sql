-- Databricks notebook source
create database if not exists f1_raw

-- COMMAND ----------

-- MAGIC %run "../includes/configaration"

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Create the table for CSV Files

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Create Circute Table

-- COMMAND ----------

drop table if exists f1_raw.circutes;
create table if not exists f1_raw.circutes(
circuteId INT,
circuteRef string,
name string,
location string,
country string,
lat double,
lng double,
alt int,
url string
)
using csv
options(path "dbfs:/mnt/formula1dlravi/raw/circuits.csv",header true)



-- COMMAND ----------

select * from f1_raw.circutes

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Create Race Table

-- COMMAND ----------

drop table if exists f1_raw.races;
create table if not exists f1_raw.races(
  raceId int,
  year int,
  round int,
  circuitId int,
  name string,
  date Date,
  time string,
  url string
)
using csv
options(path "/mnt/formula1dlravi/raw/races.csv", header true)


-- COMMAND ----------

select * from f1_raw.races

-- COMMAND ----------

show tables in f1_raw

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Create The Table For JSON File

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Create constuctor table

-- COMMAND ----------

drop table if exists f1_raw.constuctors;
create table if not exists f1_raw.constuctors(
  constructorId int,
  constructorRef string,
  name string,
  nationality string,
  url string
)
using json
options(path "/mnt/formula1dlravi/raw/constructors.json")

-- COMMAND ----------

select * from f1_raw.constuctors;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Create drivers table

-- COMMAND ----------

create table if not exists f1_raw.drivers(
  code string,
  dob date,
  driverId int,
  driverRef string,
  name struct<forname:string,surname:string>,
  nationality string,
  number int,
  url string
)
using json
options(path "/mnt/formula1dlravi/raw/drivers.json")

-- COMMAND ----------

select * from f1_raw.drivers

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Create results table

-- COMMAND ----------

drop table if exists f1_raw.results;
create table if not exists f1_raw.results(
  resultId int,
  raceId int,
  driverId int,
  constructorId int,
  number int,
  grid int,
  position int,
  positionText string,
  positionOrder int,
  points int,
  laps int,
  time string,
  milliseconds int,
  fastestLap int,
  rank int,
  fastestLapTime string,
  fastestLapSpeed string,
  statusId int
)
using json
options(path "/mnt/formula1dlravi/raw/results.json")

-- COMMAND ----------

select * from f1_raw.results

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Create pitstops table

-- COMMAND ----------

drop table if exists f1_raw.pitstops;
create table if not exists f1_raw.pitstops(
  raceId int,
  driverId int,
  stop string,
  lap int,
  time string,
  duration string,
  milliseconds int
)
using json
options(path "/mnt/formula1dlravi/raw/pit_stops.json", multiLine true)

-- COMMAND ----------

select * from f1_raw.pitstops

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###Create table for list files

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####Create laps_times table
-- MAGIC #######CSV File
-- MAGIC #######Multiple files

-- COMMAND ----------

drop table if exists f1_raw.laps_times;
create table if not exists f1_raw.laps_times(
raceId int,
driverId int,
lap int,
position int,
time string,
milliseconds int
)
using csv
options(path "/mnt/formula1dlravi/raw/lap_times")

-- COMMAND ----------

select * from f1_raw.laps_times

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###Create Qualifiying Table
-- MAGIC ######1.JSON file
-- MAGIC ######2.Multiline JSON
-- MAGIC ######3.Multiple files

-- COMMAND ----------

drop table if exists f1_raw.qualifying;
create table if not exists f1_raw.qualifying(
qualifyId int,
raceId int,
driverId int,
constructorId int,
number int,
position int,
q1 string,
q2 string,
q3 string
)
using json
options(path "/mnt/formula1dlravi/raw/qualifying",multiLine true)

-- COMMAND ----------

select * from f1_raw.qualifying

-- COMMAND ----------

desc extended f1_raw.qualifying