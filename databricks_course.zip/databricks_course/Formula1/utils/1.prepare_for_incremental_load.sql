-- Databricks notebook source
-- MAGIC %md
-- MAGIC ###Drop all tables
-- MAGIC

-- COMMAND ----------

drop database if exists f1_processed cascade

-- COMMAND ----------

create database if not exists f1_processed
location "/mnt/formula1dlgr/processed"

-- COMMAND ----------

drop database if exists f1_presentation cascade


-- COMMAND ----------

create database if not exists f1_presentation
location "/mnt/formula1dlgr/presentation"