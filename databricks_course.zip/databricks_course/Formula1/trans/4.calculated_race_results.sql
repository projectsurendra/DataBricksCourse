-- Databricks notebook source
create table if not exists race_results
(
  
)

-- COMMAND ----------

use f1_processed

-- COMMAND ----------

create table if not exists f1_presentation.calculated_race_results
using parquet
as
select races.race_year,constuctors.name team_name,drivers.name driver_name,results.position,results.points,
11-results.position as calculated_points
from results
join drivers
on results.driver_id=drivers.driver_id
join constuctors
on results.constuctor_id=constuctors.constuctor_id
join races
on results.race_id=races.race_id
where results.position <=10

-- COMMAND ----------

select * from f1_presentation.calculated_race_results