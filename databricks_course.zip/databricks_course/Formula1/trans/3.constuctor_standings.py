# Databricks notebook source
# MAGIC %md
# MAGIC ####produce the constuctortanding

# COMMAND ----------

dbutils.widgets.text("p_file_date","2021-03-21")
v_file_date=dbutils.widgets.get("p_file_date")

# COMMAND ----------

# MAGIC %run "../includes/configaration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

races_results_df=spark.read.parquet(f"{presentation_folder_path}/race_results")\
    .filter(f"file_date='{v_file_date}'")
       

# COMMAND ----------

display(races_results_df)

# COMMAND ----------

race_years_list=df_column_to_list(races_results_df,"race_year")
print(race_years_list)

# COMMAND ----------

from pyspark.sql.functions import col
races_results_df=spark.read.parquet(f"{presentation_folder_path}/race_results")\
    .filter(col("race_year").isin(race_years_list))
display(races_results_df)

# COMMAND ----------

from pyspark.sql.functions import sum,when,count,desc
constuctor_standing_df=races_results_df.groupBy("race_year","team")\
    .agg(sum("points").alias("total_points"),count(when(races_results_df.position == 1, True)).alias("wins"))
#display(constuctor_standing_df.filter("race_year=2020"))

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import desc,rank
constuctor_rank_spec=Window.partitionBy("race_year").orderBy(desc("total_points"),desc("wins"))
final_df=constuctor_standing_df.withColumn("rank",rank().over(constuctor_rank_spec))
#display(final_df.filter("race_year = 2020"))

# COMMAND ----------

#final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_presentation.constuctor_standings")
overwrite_partition(final_df,"race_year","f1_presentation","constuctor_standings")

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from f1_presentation.constuctor_standings
# MAGIC order by race_year desc