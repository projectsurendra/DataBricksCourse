# Databricks notebook source
dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
v_data_source=dbutils.widgets.get("p_data_source")

# COMMAND ----------

#first we have include the required notebooks from includes folder in to this nodebook

# COMMAND ----------

# MAGIC %run "../includes/configaration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

display(dbutils.fs.ls(raw_folder_path))

# COMMAND ----------

# MAGIC %md
# MAGIC ######step1:Read the json file using the spark dataframe reader API

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType,FloatType

# COMMAND ----------

result_schema=StructType([StructField("resultId",IntegerType(),False),
                   StructField("raceId",IntegerType(),True),
                   StructField("driverId",IntegerType(),True),
                   StructField("constructorId",IntegerType(),True),
                   StructField("number",IntegerType(),True),
                   StructField("grid",IntegerType(),True),
                   StructField("position",IntegerType(),True),
                   StructField("positionText",StringType(),True),
                   StructField("positionOrder",IntegerType(),True),
                   StructField("points",FloatType(),True),
                   StructField("laps",IntegerType(),True),
                   StructField("time",StringType(),True),
                   StructField("milliseconds",IntegerType(),True),
                   StructField("fastestLap",IntegerType(),True),
                   StructField("rank",IntegerType(),True),
                   StructField("fastestLapTime",StringType(),True),
                   StructField("FastestLapSpeed",StringType(),True),
                   StructField("statusId",IntegerType(),True)])

# COMMAND ----------

results_df=spark.read.schema(result_schema).json(f"{raw_folder_path}/results.json")
display(results_df)
results_df.printSchema

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step2:drop the unwanted columns

# COMMAND ----------

results_drop_df=results_df.drop("statusId")
display(results_drop_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step3:Rename columns

# COMMAND ----------


from pyspark.sql.functions import lit

# COMMAND ----------

results_renamed_df=results_drop_df.withColumnRenamed("resultId","result_id").withColumnRenamed("raceId","race_id")\
    .withColumnRenamed("driverId","driver_id").withColumnRenamed("constructorId","constuctor_id")\
        .withColumnRenamed("positionText","position_text").withColumnRenamed("positionOrder","position_order")\
            .withColumnRenamed("fastestLap","fastest_lap").withColumnRenamed("fastestLapTime","fastest_lap_time")\
                .withColumnRenamed("FastestLapSpeed","fastest_lap_speed").withColumn("data_source",lit(v_data_source))
display(results_renamed_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step4:add the column

# COMMAND ----------

result_final_df=add_ingestion_date(results_renamed_df)
display(result_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step5:write to output to processed container in parquet format

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

result_final_df.write.mode("overwrite").partitionBy("race_id").parquet(f"{processed_folder_path}/results")

# COMMAND ----------

dbutils.notebook.exit("Success")