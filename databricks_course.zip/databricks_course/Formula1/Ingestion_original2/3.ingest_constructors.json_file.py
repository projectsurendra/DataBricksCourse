# Databricks notebook source
dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
v_data_source=dbutils.widgets.get("p_data_source")

# COMMAND ----------

#first we have include the required notebooks from includes folder in to this nodebook

# COMMAND ----------

# MAGIC %run "../includes/configaration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

# MAGIC %md
# MAGIC Step1:Read the json file using the spark dataframe reader

# COMMAND ----------

constuctor_schema="constructorId INT,constructorRef STRING, name STRING,nationality STRING,url STRING"

# COMMAND ----------

constrctors_df=spark.read.schema(constuctor_schema).json(f"{raw_folder_path}/constructors.json")
constrctors_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Step2-drop unwanted columns from dataframe

# COMMAND ----------

constuctor_dropped_df=constrctors_df.drop("url")
constuctor_dropped_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Step3-Rename columns and add ingestion date

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,lit

# COMMAND ----------

constoctor_renamed_df=constuctor_dropped_df.withColumnRenamed("constructorId","constuctor_id")\
                      .withColumnRenamed("constructorRef","constructor_ref").withColumn("data_source",lit(v_data_source))
constoctor_final_df=add_ingestion_date(constoctor_renamed_df)

# COMMAND ----------

constoctor_final_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Step4-Write out put to parquet file

# COMMAND ----------

constoctor_final_df.write.mode("overwrite").parquet(f"{processed_folder_path}/constuctors")

# COMMAND ----------

dbutils.notebook.exit("Success")

# COMMAND ----------

# MAGIC %md
# MAGIC