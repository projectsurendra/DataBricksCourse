# Databricks notebook source
dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
v_data_source=dbutils.widgets.get("p_data_source")

# COMMAND ----------

#first we have include the required notebooks from includes folder in to this nodebook

# COMMAND ----------

# MAGIC %run "../includes/configaration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

display(dbutils.fs.ls(raw_folder_path))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### step1:Read multiline the json file by using spark reader API

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType,TimestampType

# COMMAND ----------

pit_stops_schema=StructType([StructField("raceId",IntegerType(),False),
                             StructField("driverId",IntegerType(),True),
                             StructField("stop",StringType(),True),
                             StructField("lap",IntegerType(),True),
                             StructField("time",StringType(),True),
                             StructField("duration",StringType(),True),
                             StructField("milliseconds",IntegerType(),True)])

# COMMAND ----------

pit_stops_df=spark.read.schema(pit_stops_schema).option("multiLine",True).json(f"{raw_folder_path}/pit_stops.json")
display(pit_stops_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #######Step2:Rename columns and add new columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,lit

# COMMAND ----------

final_pit_stops_df1=pit_stops_df.withColumnRenamed("driverId","driver_id").withColumnRenamed("raceId","race_id").withColumn("data_source",lit(v_data_source))
final_pit_stops_df= add_ingestion_date(final_pit_stops_df1)                 
display(final_pit_stops_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ########Stpe3:write to the output data to the processed container inparquet format

# COMMAND ----------

final_pit_stops_df.write.mode("overwrite").parquet(f"{processed_folder_path}/pit_stops")

# COMMAND ----------

dbutils.notebook.exit("Success")