# Databricks notebook source
dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
v_data_source=dbutils.widgets.get("p_data_source")

# COMMAND ----------

#first we have include the required notebooks from includes folder in to this nodebook

# COMMAND ----------

# MAGIC %run "../includes/configaration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

display(dbutils.fs.ls(raw_folder_path))

# COMMAND ----------

# MAGIC %md
# MAGIC ######Step1:Read the folder which cantains the csv file using the spark reader API

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType

# COMMAND ----------

lap_times_schem=StructType([StructField("raceId",IntegerType(),False),
                           StructField("driverId",IntegerType(),True),
                           StructField("lap",IntegerType(),True),
                           StructField("postion",IntegerType(),True),
                           StructField("time",StringType(),True),
                           StructField("milliseconds",IntegerType(),True)])

# COMMAND ----------

lap_times_df=spark.read.schema(lap_times_schem).csv(f"{raw_folder_path}/lap_times/")
display(lap_times_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Step2:Rename and add the new columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,lit

# COMMAND ----------

lap_times_final_df1 = lap_times_df.withColumnRenamed("driverId","driver_id").withColumnRenamed("raceId","race_id").withColumn("data_source",lit(v_data_source))
lap_times_final_df=add_ingestion_date(lap_times_final_df1)
display(lap_times_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ######step3:write to out put to processed container in parquet format

# COMMAND ----------

lap_times_final_df.write.mode("overwrite").parquet(f"{processed_folder_path}/laptimes")

# COMMAND ----------

display(spark.read.parquet(f"{processed_folder_path}/laptimes"))

# COMMAND ----------

dbutils.notebook.exit("Success")