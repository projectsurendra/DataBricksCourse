# Databricks notebook source
dbutils.notebook.help()

# COMMAND ----------

v_results=dbutils.notebook.run("1.Ingest _circuits_file",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_results

# COMMAND ----------

v_results=dbutils.notebook.run("2.Ingest_races_file",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_results

# COMMAND ----------

v_results=dbutils.notebook.run("3.ingest_constructors.json_file",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_results

# COMMAND ----------

v_results=dbutils.notebook.run("4.ingest_drivers.json_file",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_results

# COMMAND ----------

v_results=dbutils.notebook.run("5.ingest_results.json_file",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_results

# COMMAND ----------

v_results=dbutils.notebook.run("6.ingestion_Pitstops.multilinejson_file",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_results

# COMMAND ----------

v_results=dbutils.notebook.run("7.ingestion_lap_times_csv_file_folder",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_results

# COMMAND ----------

v_results=dbutils.notebook.run("8.ingation_Qualifying_multiline_json_file_folder",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_results