# Databricks notebook source
dbutils.widgets.text("p_data_source","")
v_data_source=dbutils.widgets.get("p_data_source")

# COMMAND ----------

#first we have include the required notebooks from includes folder in to this nodebook

# COMMAND ----------

# MAGIC %run "../includes/configaration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType,DateType

# COMMAND ----------

races_schema=StructType([StructField("raceId",IntegerType(),False),
                         StructField("year",IntegerType(),True),
                         StructField("round",IntegerType(),True),
                         StructField("circuitId",IntegerType(),True),
                         StructField("name",StringType(),True),
                         StructField("date",DateType(),True),
                         StructField("time",StringType(),True),
                         StructField("url",StringType(),True)])

# COMMAND ----------

races_df=spark.read.option("header",True).schema(races_schema).csv(f"{raw_folder_path}/races.csv")

# COMMAND ----------

races_df.show()

# COMMAND ----------

races_drop_df=races_df.drop("url")

# COMMAND ----------

races_drop_df.show()

# COMMAND ----------

races_renamed_df=races_drop_df.withColumnRenamed("raceId","race_id").withColumnRenamed("year","race_year")\
                 .withColumnRenamed("circuitId","circuit_id")

# COMMAND ----------

races_renamed_df.show()

# COMMAND ----------

race_ingest_df=add_ingestion_date(races_renamed_df)
race_ingest_df.show()

# COMMAND ----------

from pyspark.sql.functions import to_timestamp,concat,col,lit

# COMMAND ----------

race_concat_final_df=race_ingest_df.withColumn("race_timestamp",to_timestamp(concat(col("date"),lit(' '),col("time")),'yyyy-MM-dd HH:mm:ss')).drop("date","time").withColumn("data_source",lit(v_data_source))
race_concat_final_df.show()

# COMMAND ----------

race_concat_final_df.write.mode("overwrite").partitionBy("race_year").parquet(f"{processed_folder_path}/races")

# COMMAND ----------

dbutils.notebook.exit("Success")