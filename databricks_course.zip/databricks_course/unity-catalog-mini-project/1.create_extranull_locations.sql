-- Databricks notebook source
-- MAGIC %md
-- MAGIC #####Create the extranull locations required for this project
-- MAGIC ######1.Bronze
-- MAGIC ######2.Silver
-- MAGIC ######3.Gold

-- COMMAND ----------

CREATE EXTERNAL LOCATION IF NOT EXISTS databrickscourse_bronze
URL 'abfss://bronze@formula1dlgrucext.dfs.core.windows.net/'
with (STORAGE CREDENTIAL `databrickscourse-ext-storage-credentials`);

-- COMMAND ----------

desc external location databrickscourse_bronze

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(dbutils.fs.ls('abfss://bronze@formula1dlgrucext.dfs.core.windows.net/'))

-- COMMAND ----------

-- MAGIC %fs
-- MAGIC ls "abfss://bronze@formula1dlgrucext.dfs.core.windows.net/"

-- COMMAND ----------

CREATE EXTERNAL LOCATION IF NOT EXISTS databrickscourse_silver
URL 'abfss://silver@formula1dlgrucext.dfs.core.windows.net/'
with (STORAGE CREDENTIAL `databrickscourse-ext-storage-credentials`);

-- COMMAND ----------

CREATE EXTERNAL LOCATION IF NOT EXISTS databrickscourse_gold
URL 'abfss://gold@formula1dlgrucext.dfs.core.windows.net/'
with (STORAGE CREDENTIAL `databrickscourse-ext-storage-credentials`);

-- COMMAND ----------

show external locations