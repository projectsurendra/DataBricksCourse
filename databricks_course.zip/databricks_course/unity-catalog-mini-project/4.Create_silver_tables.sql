-- Databricks notebook source
-- MAGIC %md
-- MAGIC ###Create managed tables in the silver schema
-- MAGIC ####1.drivers
-- MAGIC ####2.results

-- COMMAND ----------

drop table if exists firmula1_dev.silver.drivers;
CREATE TABLE IF NOT EXISTS firmula1_dev.silver.drivers
AS
SELECT driverId as driver_id,
       driverRef as driver_ref,
       number,
       code,
       concat(name.forename,' ',name.surname ) as name,
       dob,
       nationality,
       current_timestamp() as ingestion_date
       FROM firmula1_dev.bronze.drivers;

-- COMMAND ----------

drop table if exists firmula1_dev.silver.results;
CREATE TABLE IF NOT EXISTS firmula1_dev.silver.results
AS
SELECT 
resultId as result_id,
raceId as race_id,
driverId as driver_id,
constructorId as constuctor_id,
number,
grid,
position,
positionText position_text,
positionOrder as position_order,
points,
laps,
time,
milliseconds,
fastestLap fastest_lap,
rank,
fastestLapTime as fastest_lap_time,
fastestLapSpeed as fastest_lap_speed,
statusId as status_id,
current_timestamp() as ingestion_date
FROM firmula1_dev.bronze.results;