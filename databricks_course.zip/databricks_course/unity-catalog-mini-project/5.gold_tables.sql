-- Databricks notebook source
-- MAGIC %md
-- MAGIC ###Create managed table in the gold  table
-- MAGIC #####join the driver and results to identify the number of win per drivers

-- COMMAND ----------

drop table if exists firmula1_dev.gold.driver_wins;
create table if not exists firmula1_dev.gold.driver_wins
as 
select d.name,count(1) as number_of_wins
from firmula1_dev.silver.drivers as d
join firmula1_dev.silver.results as r
on d.driver_id=r.driver_id
where r.position=1
group by d.name;


-- COMMAND ----------

select * 
from firmula1_dev.gold.driver_wins
order by number_of_wins desc