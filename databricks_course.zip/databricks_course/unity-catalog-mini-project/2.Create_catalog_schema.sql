-- Databricks notebook source
-- MAGIC %md
-- MAGIC ###Create Catalogs and Schemas Required for the project
-- MAGIC #####1.Catalog-firmula1dev(without managed location)
-- MAGIC #####2.Schemas-bronze,silver and gold(with managed location)

-- COMMAND ----------

CREATE CATALOG IF NOT EXISTS firmula1_dev;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS firmula1_dev.bronze
MANAGED LOCATION 'abfss://bronze@formula1dlgrucext.dfs.core.windows.net/'

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS firmula1_dev.silver
MANAGED LOCATION 'abfss://silver@formula1dlgrucext.dfs.core.windows.net/'

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS firmula1_dev.gold
MANAGED LOCATION 'abfss://gold@formula1dlgrucext.dfs.core.windows.net/'