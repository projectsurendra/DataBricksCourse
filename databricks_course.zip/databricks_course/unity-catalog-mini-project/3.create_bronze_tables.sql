-- Databricks notebook source
-- MAGIC %md
-- MAGIC ###Create Bronze Tables
-- MAGIC #####1.drivers.json
-- MAGIC #####2.results.json Bronze folder path-abfss://bronze@formula1dlgrucext.dfs.core.windows.net

-- COMMAND ----------

DROP TABLE if exists firmula1_dev.bronze.drivers;
CREATE TABLE IF NOT EXISTS firmula1_dev.bronze.drivers
(
  driverId int,
  driverRef string,
  number int,
  code string,
  name struct<forename:string,surname:string>,
  dob date,
  nationality string,
  url string
)
USING JSON
LOCATION 'abfss://bronze@formula1dlgrucext.dfs.core.windows.net/drivers.json'

-- COMMAND ----------

-- MAGIC %python
-- MAGIC df=spark.sql("select * from firmula1_dev.bronze.drivers")
-- MAGIC display(df)

-- COMMAND ----------

drop table if exists firmula1_dev.bronze.results;
CREATE TABLE IF NOT EXISTS firmula1_dev.bronze.results
(
resultId int,
raceId int,
driverId int,
constructorId int,
number int,
grid int,
position int,
positionText string,
positionOrder int,
points int,
laps int,
time string,
milliseconds int,
fastestLap int,
rank int,
fastestLapTime string,
fastestLapSpeed float,
statusId string
)
USING JSON
LOCATION 'abfss://bronze@formula1dlgrucext.dfs.core.windows.net/results.json'

-- COMMAND ----------

select current_schema()