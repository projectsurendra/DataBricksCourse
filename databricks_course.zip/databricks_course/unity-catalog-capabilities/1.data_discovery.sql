-- Databricks notebook source
show catalogs

-- COMMAND ----------

select * 
from `system`.information_schema.tables
where table_name='drivers'

-- COMMAND ----------

select * 
from firmula1_dev.information_schema.tables
where table_name='drivers'